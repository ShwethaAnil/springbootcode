package com.training.exceptions;
public class BuissnesException extends Exception {
public BuissnesException(String message) {
	super(message);
}

}
